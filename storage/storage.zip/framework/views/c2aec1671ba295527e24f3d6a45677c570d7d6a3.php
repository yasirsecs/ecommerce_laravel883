
<?php $__env->startPush('title'); ?>
    Amazone
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-section'); ?>
<!--main container -->

<div id="siteWrapper" class=" main-container p-5 bg-white w-full">
        <div class="mobile-navbar-top mb-5 lg:hidden">
            <div class="container mx-auto px-5 lg:px-0 flex items-center justify-between">
                    <button id="burgerButton" class="burger text-gray-700 rounded-lg bg-gray-100 hover:bg-gray-200 p-2">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                            </svg>
                    </button>
                    <div class="logo uppercase">panton</div>
                        <button id="searchButton"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
                        </svg>
                        </button>
                    </div>
            </div>
           
            <div class="container mx-auto px-5 lg:px-0 flex item-center " style="background-image: <?php echo e(url('/images/addidas_shoe.jpg')); ?>">
                <img src="<?php echo e(asset('/images/adidas_front_page2.png')); ?>" alt="Girl in a jacket" class=" w-full h-full">
                
            </div>
        </div>
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce_laravel883\resources\views/home2.blade.php ENDPATH**/ ?>