<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
 
</head>
<body>
  <h1 class="text-3xl font-bold underline">
    Hello world!
  </h1>
  <button id="myBtn">Try it</button>

  <p id="demo"></p>
  
 

  <script src="<?php echo e(asset('/js/test.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel883\resources\views/yasir.blade.php ENDPATH**/ ?>