
  //example of inline function on button click
function usersettingfunction()
{
    document.getElementById("usersetting2").classList.toggle('hidden');
}
function myFunction() {
  document.getElementById("demo").innerHTML = "Hello World";
}
