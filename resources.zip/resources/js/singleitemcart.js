const { takeRight } = require("lodash");

let carts=document.querySelectorAll('.add-cart');
 console.log("add cart value=",carts[2]);
let products=[
    {
        name:'.',
        tag:'.',
        img:'a',
        price:0,
        inCart:0
    },
    {
        name:'.',
        tag:'.',
        img:'a',
        price:0,
        inCart:0
    },
    {
        name:'.',
        tag:'.',
        img:'a',
        price:0,
        inCart:0
    },
    {
        name:'.',
        tag:'.',
        img:'a',
        price:0,
        inCart:0
    },
    {
        name:'.',
        tag:'.',
        img:'a',
        price:0,
        inCart:0
    },
    {
        name:'.',
        tag:'.',
        img:'a',
        price:0,
        inCart:0
    },
    {
        name:'.',
        tag:'.',
        img:'a',
        price:0,
        inCart:0
    },
    {
        name:'.',
        tag:'.',
        img:'a',
        price:0,
        inCart:0
    },
    {
        name:'.',
        tag:'.',
        img:'a',
        price:0,
        inCart:0
    },
    {
        name:'.',
        tag:'.',
        img:'a',
        price:0,
    }
];


/* var product_parent = document.getElementById('pid-1');
var children = product_parent.children;
inCart:0  
children[0].innerText;
console.log("number child of product_parent =",children.length);
var children_lenght=children.length;
console.log("running") */
/* var total_parent = [];
for(let j=0;j<carts.length;j++)
{
    const total_parent = [
    "pid-0",
    "pid-1",
    "pid-2",
    "pid-3",
  ];
} */
  //console.log("total_parent_second_child=",total_parent[1]);
  //console.log("lenght of carts parent=",carts.length);
for(let i=0;i<carts.length;i++)
{
    // call when click on add to cart button
    carts[i].addEventListener('click',()=>{
        var pid="pid-"+i.toString();
        htmlelementvalue(products[i],i,pid);
        cartnumbers(products[i]); 
        totalCost(products[i]);
    })
}

//set value of product properties in products array
function htmlelementvalue(product,i,pid)
{
    product.img=document.getElementById("cart-image").getAttribute('src');
    product.name=document.getElementById("card-item-name").innerText;
    var price1 = document.getElementById("cart-item-price").innerText.replace('$','');
    price1=price1.replace(',','')
    product.price=parseInt(price1);
    product.tag=document.getElementById("cart-item-tag").innerText;
    
    
}
function onLoadCartNumbers()
{
    let productNumbers =localStorage.getItem('cartNumbers');
    if(productNumbers)
    {
        document.querySelector('.cart span').textContent=productNumbers;
    }
}

function cartnumbers(product)
{
    let productNumbers=localStorage.getItem('cartNumbers');
    productNumbers=parseInt(productNumbers);

    if(productNumbers)
    {
        localStorage.setItem('cartNumbers',productNumbers+1);
        document.querySelector('.cart span').textContent=productNumbers+1;
    }
    else
    {
        localStorage.setItem('cartNumbers',1);
        //set cart value on html page
        document.querySelector('.cart span').textContent=1;
    }
    setItems(product);
}

function setItems(product)
{
let cartItems   =localStorage.getItem('productInCart');
  cartItems=JSON.parse(cartItems);
  /* console.log("cartitem="+cartItems[product.tag]); */
  if(cartItems!=null)
  {
    if(cartItems[product.tag]==undefined)
    {
        cartItems={
            ...cartItems ,[product.tag]:product
        }
    }
    cartItems[product.tag].inCart+=1;
}
else
{
    product.inCart=1;
    cartItems={[product.tag]:product}
}
localStorage.setItem("productInCart",JSON.stringify(cartItems));
}

function totalCost(product)
{
    let cartCost=localStorage.getItem('totalCost');
    console.log("my cartCost is ",cartCost);
    console.log(typeof cartCost);

    if(cartCost!=null)
    {
        console.log("cartcost===",cartCost);
        cartCost=parseInt(cartCost);
        localStorage.setItem("totalCost",cartCost+product.price);
    }
    else
    {
        let stringprice= (product.price);
        stringprice=stringprice.toString();
        localStorage.setItem("totalCost",stringprice);
        console.log("type of product.price=",typeof(stringprice));
    }
}
function displayCart()
{
    let cartItems = localStorage.getItem("productInCart");
    let carttotalcost = localStorage.getItem("totalCost");
    cartItems=JSON.parse(cartItems);
    let imagincart=document.getElementById("imagincart");
    let nameitemcart=document.getElementById("imagincart");
    let priceitemcart=document.getElementById("imagincart");
    let detailitemcart=document.getElementById("imagincart");
    let quantityitemcart=document.getElementById("imagincart");
    let removeitemcart=document.getElementById("imagincart");
    let productContainer = document.querySelector(".cart-item-list");
    let totalprice=document.getElementById("cart-price-total");

    imagincart.src="No detail provided yet";
    nameitemcart.innerText="No detail provided yet";
    priceitemcart.innerText=="No detail provided yet";
    detailitemcart.innerText="No detail provided yet";
    quantityitemcart=="No detail provided yet";
    console.log("cart item setting");
    if(cartItems&& productContainer)
    { 
        productContainer.innerHTML='';
        Object.values(cartItems).map(item=>
            {
                imagincart.src=item.img;
                nameitemcart.innerText=item.name;
                priceitemcart.innerText=item.price;
                detailitemcart.innerText="No detail provided yet";
                quantityitemcart=item.inCart;
                console.log("cart item setting");
                //removeitemcart
               /*  productContainer.innerHTML+='<li class="flex py-6">'
                      +'<div class="h-24 w-24 flex-shrink-0 overflow-hidden rounded-md border border-gray-200">'
                        +'<img src="'+item.img+'" alt="Salmon orange fabric pouch with match zipper, gray zipper pull, and adjustable hip belt." class="h-full w-full object-cover object-center">'
                      +'</div>'
                      +'<div class="ml-4 flex flex-1 flex-col">'
                        +'<div>'
                          +'<div class="flex justify-between text-base font-medium text-gray-900">'
                            +'<h3>'
                              +'<a href="#">Throwback Hip Bag</a>'
                            +'</h3>'
                            +'<p class="ml-4">$'+item.price+'.00</p>'
                          +'</div>'
                          +'<p class="mt-1 text-sm text-gray-500">'+item.name+'</p>'
                        +'</div>'
                        +'<div class="flex flex-1 items-end justify-between text-sm">'
                          +'<p class="text-gray-500">'+item.inCart+'</p>'
                          +'<div class="flex">'
                            +'<button type="button" class="font-medium text-indigo-600 hover:text-indigo-500">Remove</button>'
                          +'</div>'
                        +'</div>'
                      +'</div>'
                    +'</li>'; */
                    

                    
            })
            
            totalprice.innerText=(carttotalcost).toString();
            
            
    }

}

   // remove item from cart

let removeitemcart=document.querySelectorAll('.removeitemcart');
carts[0].addEventListener('click',()=>{
    console.log("remove item clicked");
    
})

onLoadCartNumbers();
displayCart();
